import { useState, useEffect } from "react";
import REG_ABI from "../abi/Username_registry.json";
